/* global QUnit */

sap.ui.require(["sync/ea/qfruqr/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
