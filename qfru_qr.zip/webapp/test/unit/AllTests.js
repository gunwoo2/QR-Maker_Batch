sap.ui.define([
	"syncea/qfru_qr/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
